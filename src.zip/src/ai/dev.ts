import { config } from 'dotenv';
config();

import '@/ai/flows/personalized-event-recommendations.ts';
import '@/ai/flows/ai-powered-review-moderation-flow.ts';
import '@/ai/flows/ai-assisted-event-description-flow.ts';