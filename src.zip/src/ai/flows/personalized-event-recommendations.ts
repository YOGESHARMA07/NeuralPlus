'use server';
/**
 * @fileOverview An AI agent for generating personalized event recommendations.
 *
 * - personalizedEventRecommendations - A function that handles the event recommendation process.
 * - PersonalizedEventRecommendationsInput - The input type for the personalizedEventRecommendations function.
 * - PersonalizedEventRecommendationsOutput - The return type for the personalizedEventRecommendations function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const PersonalizedEventRecommendationsInputSchema = z.object({
  browsingHistory: z.array(z.string()).describe('A list of event titles or IDs the user has recently viewed.').default([]),
  pastBookings: z.array(z.string()).describe('A list of event titles or IDs the user has previously booked.').default([]),
  interests: z.array(z.string()).describe('A list of user-specified interests (e.g., "concerts", "tech conferences").').default([]),
});
export type PersonalizedEventRecommendationsInput = z.infer<typeof PersonalizedEventRecommendationsInputSchema>;

const RecommendedEventSchema = z.object({
  id: z.string().describe('The unique identifier of the recommended event.'),
  title: z.string().describe('The title of the recommended event.'),
  description: z.string().describe('A brief description of the recommended event.'),
});

const PersonalizedEventRecommendationsOutputSchema = z.object({
  recommendedEvents: z.array(RecommendedEventSchema).describe('A list of events recommended for the user.'),
});
export type PersonalizedEventRecommendationsOutput = z.infer<typeof PersonalizedEventRecommendationsOutputSchema>;

export async function personalizedEventRecommendations(input: PersonalizedEventRecommendationsInput): Promise<PersonalizedEventRecommendationsOutput> {
  return personalizedEventRecommendationsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'personalizedEventRecommendationsPrompt',
  input: {schema: PersonalizedEventRecommendationsInputSchema},
  output: {schema: PersonalizedEventRecommendationsOutputSchema},
  prompt: `You are an AI assistant specialized in recommending events.
Your task is to generate personalized event recommendations for a user based on their past interactions and interests.

Here is the user's data:

{{#if browsingHistory}}Browsing History: {{{json browsingHistory}}}{{else}}Browsing History: None{{/if}}
{{#if pastBookings}}Past Bookings: {{{json pastBookings}}}{{else}}Past Bookings: None{{/if}}
{{#if interests}}Interests: {{{json interests}}}{{else}}Interests: None{{/if}}

Based on this information, suggest 3-5 events the user would likely enjoy. For each recommendation, provide a unique ID, a title, and a brief description. Ensure the recommendations are diverse but relevant to the user's profile.`,
});

const personalizedEventRecommendationsFlow = ai.defineFlow(
  {
    name: 'personalizedEventRecommendationsFlow',
    inputSchema: PersonalizedEventRecommendationsInputSchema,
    outputSchema: PersonalizedEventRecommendationsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
