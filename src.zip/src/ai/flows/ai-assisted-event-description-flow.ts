'use server';
/**
 * @fileOverview This file implements a Genkit flow for generating event details.
 *
 * - aiAssistedEventDescription - A function that generates an event title, description, and tags.
 * - AiAssistedEventDescriptionInput - The input type for the aiAssistedEventDescription function.
 * - AiAssistedEventDescriptionOutput - The return type for the aiAssistedEventDescription function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const AiAssistedEventDescriptionInputSchema = z.object({
  eventType: z.string().describe('The type of the event (e.g., conference, workshop, concert).'),
  mainTopic: z.string().describe('The main topic or theme of the event.'),
  targetAudience: z.string().describe('The primary audience for the event (e.g., developers, entrepreneurs, music lovers).'),
  keyHighlights: z.string().describe('Key attractions or unique features of the event (e.g., keynote speakers, interactive sessions, networking event).'),
  eventName: z.string().optional().describe('An optional existing name for the event. If provided, the AI should consider it.'),
});
export type AiAssistedEventDescriptionInput = z.infer<typeof AiAssistedEventDescriptionInputSchema>;

const AiAssistedEventDescriptionOutputSchema = z.object({
  title: z.string().describe('A compelling and catchy title for the event.'),
  description: z.string().describe('A detailed and engaging description of the event, highlighting benefits and key features.'),
  tags: z.array(z.string()).describe('A list of relevant tags to help discoverability, e.g., ["tech", "conference", "AI"]').max(7).min(3),
});
export type AiAssistedEventDescriptionOutput = z.infer<typeof AiAssistedEventDescriptionOutputSchema>;

export async function aiAssistedEventDescription(input: AiAssistedEventDescriptionInput): Promise<AiAssistedEventDescriptionOutput> {
  return aiAssistedEventDescriptionFlow(input);
}

const aiAssistedEventDescriptionPrompt = ai.definePrompt({
  name: 'aiAssistedEventDescriptionPrompt',
  input: { schema: AiAssistedEventDescriptionInputSchema },
  output: { schema: AiAssistedEventDescriptionOutputSchema },
  prompt: `You are an AI assistant specialized in creating engaging event listings. Your task is to generate a compelling event title, a detailed description, and a list of relevant tags based on the provided event details.

Event Type: {{{eventType}}}
Main Topic: {{{mainTopic}}}
Target Audience: {{{targetAudience}}}
Key Highlights: {{{keyHighlights}}}
{{#if eventName}}Existing Event Name: {{{eventName}}}{{/if}}

Please ensure the generated content is:
- **Title:** Catchy, concise, and accurately reflects the event's essence.
- **Description:** Engaging, highlights the benefits for the target audience, incorporates the key highlights, and uses clear, persuasive language. It should be at least 150 words.
- **Tags:** A comma-separated list of 3-7 highly relevant tags that will help attendees discover the event.

Return the output in JSON format, strictly following the output schema.`,
});

const aiAssistedEventDescriptionFlow = ai.defineFlow(
  {
    name: 'aiAssistedEventDescriptionFlow',
    inputSchema: AiAssistedEventDescriptionInputSchema,
    outputSchema: AiAssistedEventDescriptionOutputSchema,
  },
  async (input) => {
    const { output } = await aiAssistedEventDescriptionPrompt(input);
    return output!;
  },
);
