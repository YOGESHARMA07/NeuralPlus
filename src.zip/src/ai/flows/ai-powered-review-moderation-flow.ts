'use server';
/**
 * @fileOverview An AI content moderator for event reviews.
 *
 * - moderateReview - A function that handles the review moderation process.
 * - ReviewModerationInput - The input type for the moderateReview function.
 * - ReviewModerationOutput - The return type for the moderateReview function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ReviewModerationInputSchema = z.object({
  reviewText: z.string().describe('The event review text to be moderated.'),
});
export type ReviewModerationInput = z.infer<typeof ReviewModerationInputSchema>;

const ReviewModerationOutputSchema = z.object({
  isFlagged:
    z.boolean().describe('True if the review is deemed inappropriate, spammy, or offensive; otherwise, false.'),
  reason:
    z.string().nullable().describe('The reason for flagging the review, if flagged. Null otherwise.'),
});
export type ReviewModerationOutput = z.infer<typeof ReviewModerationOutputSchema>;

export async function moderateReview(input: ReviewModerationInput): Promise<ReviewModerationOutput> {
  return reviewModerationFlow(input);
}

const reviewModerationPrompt = ai.definePrompt({
  name: 'reviewModerationPrompt',
  input: {schema: ReviewModerationInputSchema},
  output: {schema: ReviewModerationOutputSchema},
  prompt: `You are an AI content moderator for an event marketplace. Your task is to analyze user reviews for inappropriate, spammy, or offensive content.
Carefully read the following review:

Review: {{{reviewText}}}

Based on your analysis, determine if the review should be flagged for moderation. Set 'isFlagged' to true if it contains inappropriate, spammy, or offensive content. If flagged, provide a concise 'reason' for the flagging. If the review is clean, set 'isFlagged' to false and 'reason' to null.`,
});

const reviewModerationFlow = ai.defineFlow(
  {
    name: 'reviewModerationFlow',
    inputSchema: ReviewModerationInputSchema,
    outputSchema: ReviewModerationOutputSchema,
  },
  async input => {
    const {output} = await reviewModerationPrompt(input);
    return output!;
  }
);
