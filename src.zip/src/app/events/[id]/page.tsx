"use client";

import { useState, useEffect } from 'react';
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Calendar as CalendarIcon, 
  MapPin, 
  Share2, 
  Heart, 
  Users, 
  Clock, 
  Info,
  Ticket,
  CheckCircle2,
  Loader2,
  Video,
  MessageSquare
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useDoc, useFirestore, useMemoFirebase } from "@/firebase";
import { doc } from "firebase/firestore";
import { useParams } from 'next/navigation';
import { EventChat } from '@/components/event-chat';

export default function EventDetailPage() {
  const { id } = useParams();
  const db = useFirestore();
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const eventRef = useMemoFirebase(() => {
    if (!id) return null;
    return doc(db, 'events', id as string);
  }, [db, id]);

  const { data: event, isLoading } = useDoc(eventRef);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  if (!event) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
        <h2 className="text-2xl font-bold font-headline">Event not found</h2>
        <Button variant="outline" className="rounded-xl" onClick={() => window.history.back()}>Go Back</Button>
      </div>
    );
  }

  const startDateStr = isMounted && event.startDate?.seconds ? new Date(event.startDate.seconds * 1000).toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  }) : 'TBA';

  const startTimeStr = isMounted && event.startDate?.seconds ? new Date(event.startDate.seconds * 1000).toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit'
  }) : '';

  return (
    <div className="pb-20">
      {/* Hero Header */}
      <div className="relative h-[450px] md:h-[550px]">
        <Image 
          src={event.bannerImageUrl || `https://picsum.photos/seed/${event.id}/1200/600`} 
          alt={event.title} 
          fill 
          className="object-cover"
          priority
          data-ai-hint="event cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-6 md:p-12">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="space-y-4 max-w-3xl">
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary" className="bg-white/20 text-white backdrop-blur-md border-none uppercase tracking-widest px-3">
                  {event.category}
                </Badge>
                {event.isVirtual && (
                  <Badge variant="secondary" className="bg-blue-500/20 text-blue-200 backdrop-blur-md border-none uppercase tracking-widest px-3 flex gap-1 items-center">
                    <Video className="w-3 h-3" /> Virtual
                  </Badge>
                )}
              </div>
              <h1 className="text-4xl md:text-6xl font-headline font-bold text-white leading-tight">
                {event.title}
              </h1>
              <div className="flex flex-col sm:flex-row gap-4 sm:gap-10 text-white/90">
                <div className="flex items-center gap-3">
                  <div className="bg-white/10 p-2 rounded-lg">
                    <CalendarIcon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs uppercase font-bold text-white/50">Date & Time</p>
                    <p className="font-medium">{startDateStr} {startTimeStr && `• ${startTimeStr}`}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="bg-white/10 p-2 rounded-lg">
                    <MapPin className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs uppercase font-bold text-white/50">Location</p>
                    <p className="font-medium">{event.isVirtual ? 'Join from anywhere' : (event.location || 'Physical Venue')}</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button size="icon" variant="outline" className="rounded-full w-12 h-12 bg-white/10 text-white border-white/20 hover:bg-white/20 backdrop-blur-sm">
                <Share2 className="w-5 h-5" />
              </Button>
              <Button size="icon" variant="outline" className="rounded-full w-12 h-12 bg-white/10 text-white border-white/20 hover:bg-white/20 backdrop-blur-sm">
                <Heart className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2 space-y-12">
            <Tabs defaultValue="about" className="w-full">
              <TabsList className="grid w-full grid-cols-3 max-w-lg bg-transparent h-14 p-1 border-b rounded-none gap-8">
                <TabsTrigger value="about" className="data-[state=active]:border-primary data-[state=active]:text-primary border-b-2 border-transparent rounded-none bg-transparent shadow-none px-0 text-base font-bold">About</TabsTrigger>
                <TabsTrigger value="chat" className="data-[state=active]:border-primary data-[state=active]:text-primary border-b-2 border-transparent rounded-none bg-transparent shadow-none px-0 text-base font-bold flex gap-2">
                  Chat <Badge variant="secondary" className="px-1.5 h-5 min-w-5 justify-center">NEW</Badge>
                </TabsTrigger>
                <TabsTrigger value="reviews" className="data-[state=active]:border-primary data-[state=active]:text-primary border-b-2 border-transparent rounded-none bg-transparent shadow-none px-0 text-base font-bold">Reviews</TabsTrigger>
              </TabsList>
              
              <TabsContent value="about" className="pt-10 space-y-10">
                <div className="prose prose-lg max-w-none">
                  <h3 className="text-2xl font-bold font-headline mb-6">About this experience</h3>
                  <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap text-lg">
                    {event.description}
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-primary/5 border-none shadow-none rounded-2xl">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Info className="w-5 h-5 text-primary" /> Key Information
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center gap-3">
                        <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                        <span className="text-sm font-medium">{event.isVirtual ? 'Link shared after booking' : 'Entrance via QR Code'}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                        <span className="text-sm font-medium">No refunds after 24h before event</span>
                      </div>
                      {event.ageRestriction && (
                        <div className="flex items-center gap-3">
                          <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                          <span className="text-sm font-medium">Age Limit: {event.ageRestriction}+ years</span>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-secondary/30 border-none shadow-none rounded-2xl">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Users className="w-5 h-5 text-secondary-foreground" /> Community
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex -space-x-3 mb-4 overflow-hidden">
                        {[1,2,3,4,5].map(i => (
                          <Avatar key={i} className="border-2 border-white w-10 h-10">
                            <AvatarImage src={`https://i.pravatar.cc/150?u=${i}`} />
                            <AvatarFallback>U</AvatarFallback>
                          </Avatar>
                        ))}
                        <div className="flex items-center justify-center w-10 h-10 rounded-full bg-white border-2 border-white text-[10px] font-bold text-muted-foreground">
                          +1k
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">Join 1,200+ people interested in this event.</p>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="chat" className="pt-10">
                <EventChat eventId={event.id} />
              </TabsContent>
              
              <TabsContent value="reviews" className="pt-10">
                <div className="py-20 text-center border-2 border-dashed rounded-3xl space-y-4">
                  <div className="bg-muted w-16 h-16 rounded-full flex items-center justify-center mx-auto">
                    <MessageSquare className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <div>
                    <h4 className="font-bold text-xl">No reviews yet</h4>
                    <p className="text-muted-foreground">Be the first to share your experience after attending!</p>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          <aside className="space-y-6">
            <Card className="sticky top-24 border-2 border-primary shadow-2xl rounded-3xl overflow-hidden">
              <CardHeader className="bg-primary/5 pb-8 pt-8">
                <CardTitle className="text-xs font-bold uppercase tracking-[0.2em] text-muted-foreground">Current Pricing</CardTitle>
                <div className="flex items-baseline gap-2 mt-4">
                  <span className="text-5xl font-bold text-primary font-headline tracking-tighter">
                    {event.price === 0 ? "FREE" : `$${event.price}`}
                  </span>
                  {event.price > 0 && <span className="text-muted-foreground font-medium">/ per person</span>}
                </div>
              </CardHeader>
              <CardContent className="pt-8 space-y-8">
                <div className="space-y-5">
                  <div className="flex items-start gap-4">
                    <Clock className="w-5 h-5 text-muted-foreground shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-bold">Standard Admission</p>
                      <p className="text-sm text-muted-foreground">Registration closes soon</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <Ticket className="w-5 h-5 text-muted-foreground shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-bold">Tickets Remaining</p>
                      <p className="text-sm text-muted-foreground">Limited availability</p>
                    </div>
                  </div>
                </div>
                
                <Button className="w-full h-16 text-xl font-bold shadow-xl shadow-primary/30 rounded-2xl transition-transform hover:scale-[1.02] active:scale-[0.98]">
                  Secure My Spot
                </Button>
                
                <div className="text-[10px] text-center text-muted-foreground px-6 space-y-1">
                  <p>Secured by EventFlex Trust & Safety</p>
                  <p>By booking, you agree to the Organizer's policy.</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-md bg-white rounded-3xl">
              <CardHeader>
                <CardTitle className="text-lg">Meet the Host</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center font-bold text-primary text-xl uppercase overflow-hidden">
                    {event.category?.substring(0, 2)}
                  </div>
                  <div>
                    <h4 className="font-bold text-lg leading-tight">Elite Events Group</h4>
                    <Badge variant="secondary" className="bg-green-50 text-green-700 mt-1 border-none text-[10px]">VERIFIED ORGANIZER</Badge>
                  </div>
                </div>
                <Button variant="outline" className="w-full rounded-xl py-6 font-bold">Follow Organizer</Button>
              </CardContent>
            </Card>
          </aside>
        </div>
      </div>
    </div>
  );
}
