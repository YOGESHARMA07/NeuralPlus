"use client";

import { useState, useMemo, useEffect, Suspense } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { 
  Search, 
  MapPin, 
  Calendar, 
  LayoutGrid,
  List,
  SlidersHorizontal,
  Loader2,
  FilterX
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import Image from "next/image";
import Link from "next/link";
import { useCollection, useFirestore, useMemoFirebase } from "@/firebase";
import { collection, query, where, orderBy, limit } from "firebase/firestore";
import { useSearchParams } from "next/navigation";

const CATEGORIES = ["Music", "Tech", "Food", "Arts", "Business", "Sports"];

function EventsList() {
  const searchParams = useSearchParams();
  const urlCategory = searchParams.get('category');
  const urlQuery = searchParams.get('q');

  const [view, setView] = useState<"grid" | "list">("grid");
  const [priceRange, setPriceRange] = useState([0, 1000]);
  const [searchTerm, setSearchTerm] = useState(urlQuery || "");
  const [selectedCategories, setSelectedCategories] = useState<string[]>(urlCategory ? [urlCategory] : []);
  const [isMounted, setIsMounted] = useState(false);
  
  const db = useFirestore();

  useEffect(() => {
    setIsMounted(true);
  }, []);

  useEffect(() => {
    if (urlCategory) {
      setSelectedCategories(prev => prev.includes(urlCategory) ? prev : [...prev, urlCategory]);
    }
  }, [urlCategory]);

  useEffect(() => {
    if (urlQuery) {
      setSearchTerm(urlQuery);
    }
  }, [urlQuery]);

  const eventsQuery = useMemoFirebase(() => {
    return query(
      collection(db, 'events'), 
      where('status', '==', 'published'),
      orderBy('createdAt', 'desc'),
      limit(50)
    );
  }, [db]);

  const { data: rawEvents, isLoading, error: queryError } = useCollection(eventsQuery);

  const filteredEvents = useMemo(() => {
    if (!rawEvents) return [];
    return rawEvents.filter(event => {
      const matchesSearch = 
        event.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
        (event.location?.toLowerCase() || "").includes(searchTerm.toLowerCase());
      
      const matchesCategory = selectedCategories.length === 0 || selectedCategories.includes(event.category);
      const matchesPrice = (event.price || 0) >= priceRange[0] && (event.price || 0) <= priceRange[1];
      
      return matchesSearch && matchesCategory && matchesPrice;
    });
  }, [rawEvents, searchTerm, priceRange, selectedCategories]);

  const toggleCategory = (cat: string) => {
    setSelectedCategories(prev => 
      prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]
    );
  };

  const clearFilters = () => {
    setSelectedCategories([]);
    setPriceRange([0, 1000]);
    setSearchTerm("");
  };

  return (
    <div className="flex flex-col md:flex-row gap-8">
      <aside className="w-full md:w-64 space-y-8 shrink-0">
        <div className="flex items-center justify-between border-b pb-4">
          <h2 className="text-xl font-bold font-headline flex items-center gap-2">
            <SlidersHorizontal className="w-5 h-5" /> Filters
          </h2>
          <Button 
            variant="link" 
            size="sm" 
            className="text-primary h-auto p-0"
            onClick={clearFilters}
          >
            Clear All
          </Button>
        </div>

        <div className="space-y-4">
          <h3 className="font-bold text-sm uppercase tracking-wider text-muted-foreground">Category</h3>
          <div className="space-y-2">
            {CATEGORIES.map((cat) => (
              <div key={cat} className="flex items-center space-x-2">
                <Checkbox 
                  id={cat} 
                  checked={selectedCategories.includes(cat)}
                  onCheckedChange={() => toggleCategory(cat)}
                />
                <label htmlFor={cat} className="text-sm font-medium leading-none cursor-pointer">
                  {cat}
                </label>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm uppercase tracking-wider text-muted-foreground">Price Range</h3>
            <span className="text-xs font-bold text-primary">${priceRange[0]} - ${priceRange[1]}</span>
          </div>
          <Slider 
            value={priceRange} 
            max={1000} 
            step={10} 
            onValueChange={setPriceRange}
          />
        </div>
      </aside>

      <div className="flex-1 space-y-6">
        <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-white p-4 rounded-2xl border shadow-sm">
          <div className="flex items-center gap-4 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Search keywords or location..." 
                className="pl-10 bg-muted/50 border-none rounded-xl"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <div className="flex items-center gap-2 border-l pl-4">
            <Button 
              variant={view === 'grid' ? 'default' : 'ghost'} 
              size="icon" 
              onClick={() => setView('grid')}
              className="w-10 h-10 rounded-xl"
            >
              <LayoutGrid className="w-4 h-4" />
            </Button>
            <Button 
              variant={view === 'list' ? 'default' : 'ghost'} 
              size="icon" 
              onClick={() => setView('list')}
              className="w-10 h-10 rounded-xl"
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-10 h-10 animate-spin text-primary" />
          </div>
        ) : queryError ? (
          <div className="text-center py-20 bg-destructive/5 rounded-3xl border-2 border-dashed border-destructive/20 space-y-4">
            <p className="text-destructive font-bold">Discovery Access Error</p>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              Our security rules are currently being synchronized. Please wait a moment and try again.
            </p>
            <Button onClick={() => window.location.reload()}>Retry Discovery</Button>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-muted-foreground">
                Showing <span className="text-foreground font-bold">{filteredEvents.length}</span> events found
              </p>
            </div>

            <div className={view === 'grid' ? "grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6" : "space-y-4"}>
              {filteredEvents.map((event) => (
                <Link key={event.id} href={`/events/${event.id}`}>
                  <Card className={`group hover:shadow-lg transition-all border-none overflow-hidden h-full ${view === 'list' ? 'flex flex-row' : 'flex flex-col'}`}>
                    <div className={`relative ${view === 'grid' ? 'h-48 w-full' : 'w-48 shrink-0'}`}>
                      <Image 
                        src={event.bannerImageUrl || `https://picsum.photos/seed/${event.id}/600/400`} 
                        alt={event.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-500"
                        data-ai-hint="event photo"
                      />
                      <Badge className="absolute top-2 right-2 bg-white/90 text-primary hover:bg-white font-bold backdrop-blur-sm border-none shadow-sm">
                        {event.price === 0 ? "FREE" : `$${event.price}`}
                      </Badge>
                    </div>
                    <CardContent className="p-5 flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <Badge variant="secondary" className="text-[10px] font-bold uppercase tracking-widest">{event.category}</Badge>
                        </div>
                        <h3 className="font-bold text-lg mb-3 line-clamp-2 group-hover:text-primary transition-colors leading-tight">{event.title}</h3>
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-sm text-muted-foreground font-medium">
                            <Calendar className="w-4 h-4 text-primary" />
                            {isMounted && event.startDate?.seconds ? new Date(event.startDate.seconds * 1000).toLocaleDateString() : 'TBA'}
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground font-medium">
                            <MapPin className="w-4 h-4 text-primary" />
                            <span className="truncate">{event.location || (event.isVirtual ? 'Online' : 'Venue TBA')}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
            
            {filteredEvents.length === 0 && (
              <div className="text-center py-20 bg-muted/10 rounded-[2rem] border-2 border-dashed space-y-6">
                <FilterX className="w-16 h-16 text-muted-foreground mx-auto opacity-20" />
                <div>
                  <h3 className="text-xl font-bold">No events match your search</h3>
                  <p className="text-muted-foreground mt-2">Try adjusting your filters or search keywords.</p>
                </div>
                <Button onClick={clearFilters} variant="outline" className="rounded-xl px-8">Reset All Filters</Button>
              </div>
            )}
          </>
        )}

        {filteredEvents.length > 0 && (
          <div className="flex justify-center pt-12">
            <Button variant="outline" size="lg" className="rounded-full px-8 font-bold border-2">Load More Experiences</Button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function EventsPage() {
  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <Suspense fallback={
        <div className="flex justify-center py-20">
          <Loader2 className="w-10 h-10 animate-spin text-primary" />
        </div>
      }>
        <EventsList />
      </Suspense>
    </div>
  );
}