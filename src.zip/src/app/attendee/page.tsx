"use client";

import { useState, useEffect } from "react";
import { useUser, useCollection, useFirestore, useMemoFirebase } from "@/firebase";
import { collection, query, orderBy, limit } from "firebase/firestore";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Ticket, MapPin, ArrowRight, Loader2, Heart } from "lucide-react";
import Link from "next/link";

export default function AttendeeDashboard() {
  const { user } = useUser();
  const db = useFirestore();
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const bookingsQuery = useMemoFirebase(() => {
    if (!user) return null;
    return query(
      collection(db, "users", user.uid, "bookings"),
      orderBy("bookingDate", "desc"),
      limit(5)
    );
  }, [db, user]);

  const { data: bookings, isLoading } = useCollection(bookingsQuery);

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
        <h1 className="text-2xl font-bold font-headline">Please log in to view your dashboard</h1>
        <Button asChild className="rounded-xl"><Link href="/login">Login</Link></Button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-6 py-12 space-y-10">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl md:text-4xl font-headline font-bold">Welcome back, {user.displayName?.split(' ')[0]}!</h1>
          <p className="text-muted-foreground">Manage your upcoming experiences and tickets</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="rounded-xl font-bold" asChild>
            <Link href="/attendee/tickets">View All Tickets</Link>
          </Button>
          <Button className="rounded-xl font-bold" asChild>
            <Link href="/events">Explore Events</Link>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <Card className="border-none shadow-sm overflow-hidden">
            <CardHeader className="bg-muted/10">
              <CardTitle className="flex items-center gap-2">
                <Ticket className="w-5 h-5 text-primary" /> Recent Bookings
              </CardTitle>
              <CardDescription>Your latest confirmed event registrations</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="flex justify-center p-12">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              ) : bookings && bookings.length > 0 ? (
                <div className="divide-y">
                  {bookings.map((booking) => (
                    <div key={booking.id} className="p-6 flex items-center justify-between hover:bg-muted/5 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                          <Calendar className="w-6 h-6" />
                        </div>
                        <div>
                          <p className="font-bold">Order #{booking.id.substring(0, 8).toUpperCase()}</p>
                          <p className="text-sm text-muted-foreground">
                            Booked on {isMounted && booking.bookingDate?.seconds ? new Date(booking.bookingDate.seconds * 1000).toLocaleDateString() : '...'}
                          </p>
                        </div>
                      </div>
                      <div className="text-right flex items-center gap-4">
                        <div>
                          <p className="font-bold text-primary">${booking.totalAmount}</p>
                          <Badge className="rounded-full bg-green-50 text-green-700 border-none">{booking.status}</Badge>
                        </div>
                        <Button size="icon" variant="ghost" className="rounded-full" asChild>
                          <Link href="/attendee/tickets">
                            <ArrowRight className="w-4 h-4" />
                          </Link>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16 text-muted-foreground">
                  <p>You haven't booked any events yet.</p>
                  <Button variant="link" asChild><Link href="/events">Find an experience</Link></Button>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="border-none shadow-sm bg-primary/5">
              <CardContent className="p-6 space-y-4">
                <div className="bg-white w-10 h-10 rounded-lg flex items-center justify-center shadow-sm">
                  <Heart className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">My Wishlist</h3>
                  <p className="text-sm text-muted-foreground">Events you've saved for later</p>
                </div>
                <Button variant="outline" className="w-full bg-white border-none shadow-sm rounded-xl">View Wishlist</Button>
              </CardContent>
            </Card>
            <Card className="border-none shadow-sm bg-blue-50">
              <CardContent className="p-6 space-y-4">
                <div className="bg-white w-10 h-10 rounded-lg flex items-center justify-center shadow-sm">
                  <MapPin className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Local Discovery</h3>
                  <p className="text-sm text-muted-foreground">Top events happening near you</p>
                </div>
                <Button variant="outline" className="w-full bg-white border-none shadow-sm rounded-xl" asChild>
                  <Link href="/events">Browse Map</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        <aside className="space-y-6">
          <Card className="border-none shadow-sm bg-foreground text-white rounded-[2rem] overflow-hidden">
            <CardContent className="p-8 space-y-6">
              <h3 className="text-2xl font-bold font-headline leading-tight">Explore the <span className="text-primary italic">Marketplace</span></h3>
              <p className="text-gray-400 text-sm">Discover thousands of unique events from independent organizers globally.</p>
              <div className="space-y-3">
                {["Music", "Tech", "Food", "Arts"].map(cat => (
                  <Link key={cat} href={`/events?category=${cat}`} className="flex items-center justify-between group p-3 rounded-xl hover:bg-white/10 transition-colors">
                    <span className="font-medium">{cat}</span>
                    <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </Link>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg">Need Help?</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">Our support team is available 24/7 to help with your bookings.</p>
              <Button variant="outline" className="w-full rounded-xl">Contact Support</Button>
            </CardContent>
          </Card>
        </aside>
      </div>
    </div>
  );
}
