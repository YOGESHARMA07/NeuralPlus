"use client";

import { useUser, useCollection, useFirestore, useMemoFirebase } from "@/firebase";
import { collectionGroup, query, where, orderBy } from "firebase/firestore";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Ticket, Calendar, MapPin, Download, Share2, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState, useMemo } from "react";
import Image from "next/image";
import Link from "next/link";

export default function MyTicketsPage() {
  const { user } = useUser();
  const db = useFirestore();
  const [searchTerm, setSearchTerm] = useState("");

  const ticketsQuery = useMemoFirebase(() => {
    if (!user) return null;
    return query(
      collectionGroup(db, "bookingTickets"),
      where("attendeeId", "==", user.uid)
    );
  }, [db, user]);

  const { data: tickets, isLoading } = useCollection(ticketsQuery);

  const filteredTickets = useMemo(() => {
    if (!tickets) return [];
    return tickets.filter(t => 
      t.ticketCode?.toLowerCase().includes(searchTerm.toLowerCase()) || 
      t.attendeeName?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [tickets, searchTerm]);

  if (!user) return null;

  return (
    <div className="max-w-5xl mx-auto px-6 py-12 space-y-8">
      <div className="space-y-2">
        <h1 className="text-3xl font-headline font-bold">My Tickets</h1>
        <p className="text-muted-foreground">Access your entry codes and event details</p>
      </div>

      <div className="flex items-center gap-4 bg-white p-4 rounded-2xl border shadow-sm">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search by code or attendee..." 
            className="pl-10 bg-muted/50 border-none rounded-xl"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="w-10 h-10 animate-spin text-primary" />
        </div>
      ) : filteredTickets.length > 0 ? (
        <div className="grid grid-cols-1 gap-6">
          {filteredTickets.map((ticket) => (
            <Card key={ticket.id} className="overflow-hidden border-none shadow-md hover:shadow-lg transition-shadow group">
              <div className="flex flex-col md:flex-row">
                <div className="relative w-full md:w-64 h-48 md:h-auto shrink-0 bg-primary/5 flex items-center justify-center border-r border-dashed">
                  <div className="p-4 bg-white rounded-2xl shadow-xl">
                    <Image 
                      src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${ticket.ticketCode}`}
                      alt="Ticket QR Code"
                      width={120}
                      height={120}
                      className="rounded-lg"
                    />
                  </div>
                </div>

                <CardContent className="p-8 flex-1 flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary" className="bg-primary/10 text-primary uppercase font-bold tracking-widest text-[10px]">
                        {ticket.status === 'checked-in' ? 'Used' : 'Valid Entry'}
                      </Badge>
                      <span className="font-mono text-sm font-bold text-muted-foreground">{ticket.ticketCode}</span>
                    </div>
                    <h3 className="text-2xl font-bold group-hover:text-primary transition-colors">Event Ticket</h3>
                    <div className="grid grid-cols-2 gap-6">
                      <div className="flex items-center gap-3 text-muted-foreground">
                        <div className="p-2 rounded-lg bg-muted text-primary"><Calendar className="w-4 h-4" /></div>
                        <div>
                          <p className="text-[10px] font-bold uppercase">Date</p>
                          <p className="text-sm font-medium text-foreground">See Event</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 text-muted-foreground">
                        <div className="p-2 rounded-lg bg-muted text-primary"><MapPin className="w-4 h-4" /></div>
                        <div>
                          <p className="text-[10px] font-bold uppercase">Location</p>
                          <p className="text-sm font-medium text-foreground">Physical Ticket</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-8 pt-6 border-t flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center font-bold text-[10px]">
                        {ticket.attendeeName?.substring(0, 2).toUpperCase()}
                      </div>
                      <p className="text-sm font-medium">{ticket.attendeeName}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="icon" className="rounded-xl"><Share2 className="w-4 h-4" /></Button>
                      <Button variant="outline" className="rounded-xl gap-2 font-bold">
                        <Download className="w-4 h-4" /> PDF
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-muted/10 rounded-[2.5rem] border-2 border-dashed space-y-4">
          <Ticket className="w-16 h-16 text-muted-foreground mx-auto opacity-20" />
          <h3 className="text-xl font-bold">No tickets found</h3>
          <p className="text-muted-foreground">Try searching for a different code or browse more events.</p>
          <Button asChild className="rounded-xl px-8 font-bold"><Link href="/events">Discover Events</Link></Button>
        </div>
      )}
    </div>
  );
}