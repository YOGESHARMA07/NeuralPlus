"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles, Calendar, MapPin, Ticket, Image as ImageIcon, CheckCircle2, Wand2, Loader2 } from "lucide-react";
import { aiAssistedEventDescription } from "@/ai/flows/ai-assisted-event-description-flow";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { useFirestore, useUser, setDocumentNonBlocking } from "@/firebase";
import { doc, serverTimestamp, collection } from "firebase/firestore";

export default function CreateEventPage() {
  const [step, setStep] = useState(1);
  const router = useRouter();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const { user } = useUser();
  const db = useFirestore();
  
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    type: "Conference",
    topic: "",
    audience: "",
    highlights: "",
    date: "",
    location: "",
    price: "0",
    tags: [] as string[]
  });

  const handleAiAssist = async () => {
    if (!formData.topic || !formData.audience || !formData.highlights) {
      toast({
        title: "Missing Info",
        description: "Please fill in Topic, Audience, and Highlights first.",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const result = await aiAssistedEventDescription({
        eventType: formData.type,
        mainTopic: formData.topic,
        targetAudience: formData.audience,
        keyHighlights: formData.highlights,
        eventName: formData.title || undefined
      });

      setFormData(prev => ({
        ...prev,
        title: result.title,
        description: result.description,
        tags: result.tags
      }));

      toast({
        title: "AI Generation Success!",
        description: "Your event details have been optimized by AI."
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate AI content.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePublish = (status: 'published' | 'draft') => {
    if (!user) {
      toast({ title: "Auth Required", description: "You must be logged in to create events.", variant: "destructive" });
      return;
    }

    if (!formData.title || !formData.date) {
      toast({ title: "Missing Fields", description: "Title and Date are required.", variant: "destructive" });
      return;
    }

    const eventId = doc(collection(db, 'events')).id;
    const eventRef = status === 'published' 
      ? doc(db, 'events', eventId)
      : doc(db, 'users', user.uid, 'draftEvents', eventId);

    const eventData = {
      id: eventId,
      organizerId: user.uid,
      title: formData.title,
      description: formData.description,
      category: formData.type,
      tagIds: formData.tags,
      startDate: new Date(formData.date),
      endDate: new Date(new Date(formData.date).getTime() + 3600000), // Default 1hr duration
      status,
      price: parseFloat(formData.price) || 0,
      isVirtual: formData.location.toLowerCase().includes('virtual') || formData.location.toLowerCase().includes('online'),
      location: formData.location,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      bannerImageUrl: `https://picsum.photos/seed/${eventId}/1200/600`
    };

    setDocumentNonBlocking(eventRef, eventData, { merge: true });

    toast({
      title: status === 'published' ? "Event Published!" : "Draft Saved",
      description: status === 'published' ? "Your event is now live." : "You can find it in your dashboard."
    });

    router.push('/organizer');
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-12 space-y-8">
      <div className="flex items-center justify-between border-b pb-8">
        <div className="space-y-1">
          <h1 className="text-3xl font-headline font-bold">List Your Event</h1>
          <p className="text-muted-foreground">Reach thousands of attendees globally</p>
        </div>
        <div className="flex gap-2">
          {[1, 2, 3].map(s => (
            <div key={s} className={`h-2 w-12 rounded-full ${s <= step ? 'bg-primary' : 'bg-muted'}`} />
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <nav className="md:col-span-1 space-y-1">
          {[
            { id: 1, label: "Basic Info", icon: Calendar },
            { id: 2, label: "Event Details", icon: ImageIcon },
            { id: 3, label: "Finalize", icon: Ticket }
          ].map((s) => (
            <button
              key={s.id}
              onClick={() => setStep(s.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${step === s.id ? 'bg-primary/10 text-primary font-bold' : 'text-muted-foreground hover:bg-muted'}`}
            >
              <s.icon className="w-5 h-5" />
              <span className="text-sm">{s.label}</span>
            </button>
          ))}
        </nav>

        <div className="md:col-span-3">
          {step === 1 && (
            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle>Step 1: The Basics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">Event Title</Label>
                  <Input 
                    id="title" 
                    placeholder="e.g. Annual Tech Summit" 
                    value={formData.title}
                    onChange={e => setFormData({...formData, title: e.target.value})}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="type">Event Type / Category</Label>
                    <Input id="type" value={formData.type} onChange={e => setFormData({...formData, type: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="location">Location</Label>
                    <Input id="location" placeholder="San Francisco or Virtual" value={formData.location} onChange={e => setFormData({...formData, location: e.target.value})} />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="date">Date & Time</Label>
                    <Input id="date" type="datetime-local" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="price">Base Price ($)</Label>
                    <Input id="price" type="number" placeholder="0 for Free" value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <Card className="border-2 border-primary/20 bg-primary/5 shadow-none overflow-hidden">
                <CardHeader className="bg-primary/5 pb-4">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-primary" /> AI Content Generator
                    </CardTitle>
                    <Button 
                      onClick={handleAiAssist} 
                      disabled={loading} 
                      className="rounded-full gap-2 font-bold"
                      size="sm"
                    >
                      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
                      Generate Description
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-xs font-bold uppercase">Main Topic</Label>
                      <Input placeholder="e.g. Artificial Intelligence" value={formData.topic} onChange={e => setFormData({...formData, topic: e.target.value})} />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs font-bold uppercase">Target Audience</Label>
                      <Input placeholder="e.g. Tech Professionals" value={formData.audience} onChange={e => setFormData({...formData, audience: e.target.value})} />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-bold uppercase">Key Highlights</Label>
                    <Textarea 
                      placeholder="e.g. 3 keynote speakers, networking lunch, interactive workshops..." 
                      className="h-20"
                      value={formData.highlights}
                      onChange={e => setFormData({...formData, highlights: e.target.value})}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-none shadow-sm">
                <CardHeader>
                  <CardTitle>Event Description</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="desc">Detailed Content</Label>
                    <Textarea 
                      id="desc" 
                      placeholder="Give people a reason to attend!" 
                      className="min-h-[200px]"
                      value={formData.description}
                      onChange={e => setFormData({...formData, description: e.target.value})}
                    />
                  </div>
                  {formData.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      <span className="text-xs font-bold text-muted-foreground w-full mb-1">RECOMMENDED TAGS:</span>
                      {formData.tags.map(tag => (
                        <Badge key={tag} variant="secondary" className="px-3 py-1">{tag}</Badge>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {step === 3 && (
            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle>Final Review</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-muted/30 p-6 rounded-xl space-y-4">
                  <div className="flex justify-between border-b pb-4">
                    <span className="font-bold">Title</span>
                    <span className="text-muted-foreground">{formData.title || "Not set"}</span>
                  </div>
                  <div className="flex justify-between border-b pb-4">
                    <span className="font-bold">Category</span>
                    <span className="text-muted-foreground">{formData.type}</span>
                  </div>
                  <div className="flex justify-between border-b pb-4">
                    <span className="font-bold">Price</span>
                    <span className="text-muted-foreground">${formData.price}</span>
                  </div>
                </div>
                
                <div className="pt-6 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-green-600">
                    <CheckCircle2 className="w-5 h-5" />
                    <span className="text-sm font-medium">Ready to Publish</span>
                  </div>
                  <div className="flex gap-4">
                    <Button 
                      variant="outline" 
                      className="rounded-xl px-8"
                      onClick={() => handlePublish('draft')}
                    >
                      Save as Draft
                    </Button>
                    <Button 
                      className="rounded-xl px-12 font-bold" 
                      size="lg"
                      onClick={() => handlePublish('published')}
                    >
                      Publish Event
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="flex justify-between pt-8">
            {step > 1 && (
              <Button variant="ghost" onClick={() => setStep(step - 1)}>Back</Button>
            )}
            <div className="flex-1" />
            {step < 3 && (
              <Button className="rounded-xl px-8 font-bold" onClick={() => setStep(step + 1)}>Continue</Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}