"use client";

import { useState, useRef, useEffect } from "react";
import { useUser, useFirestore } from "@/firebase";
import { checkInTicket } from "@/lib/db";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2, Camera, CheckCircle2, XCircle, ShieldCheck, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";

export default function CheckInPage() {
  const [ticketCode, setTicketCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [hasCameraPermission, setHasCameraPermission] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();

  useEffect(() => {
    const getCameraPermission = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
        setHasCameraPermission(true);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (error) {
        console.error('Error accessing camera:', error);
        setHasCameraPermission(false);
        // Only toast if scanning was explicitly requested
        if (isScanning) {
          toast({
            variant: 'destructive',
            title: 'Camera Access Denied',
            description: 'Please enable camera permissions in your browser settings.',
          });
          setIsScanning(false);
        }
      }
    };

    if (isScanning) {
      getCameraPermission();
    } else if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
  }, [isScanning, toast]);

  const handleCheckIn = async (codeOverride?: string) => {
    const code = codeOverride || ticketCode;
    if (!code || !user) return;

    setLoading(true);
    try {
      const result = await checkInTicket(db, code, user.uid);
      toast({
        title: "Check-in Successful!",
        description: `Attendee ${result.attendeeName} is now checked in.`,
      });
      setTicketCode("");
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Check-in Failed",
        description: error.message || "Invalid ticket code.",
      });
    } finally {
      setLoading(false);
    }
  };

  if (!user) return null;

  return (
    <div className="max-w-3xl mx-auto px-6 py-12 space-y-8">
      <div className="flex items-center gap-3">
        <div className="p-3 rounded-2xl bg-primary/10 text-primary">
          <ShieldCheck className="w-8 h-8" />
        </div>
        <div>
          <h1 className="text-3xl font-headline font-bold">Attendee Check-in</h1>
          <p className="text-muted-foreground">Scan QR codes or enter ticket IDs manually</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Manual Entry */}
        <Card className="border-none shadow-sm h-full">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="w-5 h-5 text-primary" /> Manual Entry
            </CardTitle>
            <CardDescription>Enter the 8-character ticket code</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input 
              placeholder="e.g. AB12CD34" 
              className="h-14 text-xl font-mono text-center tracking-widest rounded-xl"
              value={ticketCode}
              onChange={(e) => setTicketCode(e.target.value.toUpperCase())}
            />
            <Button 
              className="w-full h-14 text-lg font-bold rounded-xl shadow-lg shadow-primary/20"
              disabled={loading || !ticketCode}
              onClick={() => handleCheckIn()}
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <CheckCircle2 className="w-5 h-5 mr-2" />}
              Validate Ticket
            </Button>
          </CardContent>
        </Card>

        {/* Scanner Section */}
        <Card className="border-none shadow-sm bg-muted/30 h-full">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Camera className="w-5 h-5 text-primary" /> Live Scanner
            </CardTitle>
            <CardDescription>Use your camera to scan QR codes</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative aspect-square bg-black rounded-2xl overflow-hidden flex items-center justify-center">
              <video 
                ref={videoRef} 
                className={`w-full h-full object-cover ${!isScanning ? 'hidden' : ''}`} 
                autoPlay 
                muted 
                playsInline
              />
              {!isScanning && (
                <Button 
                  variant="secondary" 
                  className="rounded-full h-20 w-20 flex flex-col gap-1 shadow-xl"
                  onClick={() => setIsScanning(true)}
                >
                  <Camera className="w-8 h-8" />
                  <span className="text-[10px] font-bold">START</span>
                </Button>
              )}
              {isScanning && (
                <>
                  <div className="absolute inset-0 border-4 border-primary/50 border-dashed rounded-2xl m-8 pointer-events-none animate-pulse" />
                  <Button 
                    size="sm" 
                    variant="destructive" 
                    className="absolute bottom-4 rounded-full"
                    onClick={() => setIsScanning(false)}
                  >
                    <XCircle className="w-4 h-4 mr-2" /> Stop Scanner
                  </Button>
                </>
              )}
            </div>
            
            {isScanning && !hasCameraPermission && (
              <Alert variant="destructive" className="mt-4">
                <AlertTitle>Camera Access Required</AlertTitle>
                <AlertDescription>
                  Please allow camera access to use the live QR scanner feature.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">Recent Scans</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-sm text-muted-foreground text-center py-8 opacity-50 border-2 border-dashed rounded-2xl">
            <p>Scanning history will appear here during this session.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
