"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Plus, 
  BarChart3, 
  Users, 
  Ticket, 
  DollarSign, 
  MoreHorizontal,
  ExternalLink,
  Edit2,
  Trash2,
  Calendar,
  Loader2,
  TrendingUp,
  Database
} from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useCollection, useFirestore, useMemoFirebase, useUser } from "@/firebase";
import { collection, query, where, orderBy } from "firebase/firestore";
import { seedSampleEvents } from "@/lib/db";
import { useToast } from "@/hooks/use-toast";
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';

const REVENUE_DATA = [
  { name: 'Mon', total: 400 },
  { name: 'Tue', total: 300 },
  { name: 'Wed', total: 200 },
  { name: 'Thu', total: 278 },
  { name: 'Fri', total: 189 },
  { name: 'Sat', total: 239 },
  { name: 'Sun', total: 349 },
];

const ATTENDEE_DATA = [
  { name: 'Jan', count: 400 },
  { name: 'Feb', count: 300 },
  { name: 'Mar', count: 600 },
  { name: 'Apr', count: 800 },
  { name: 'May', count: 500 },
  { name: 'Jun', count: 900 },
];

export default function OrganizerDashboard() {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();
  const [isMounted, setIsMounted] = useState(false);
  const [seeding, setSeeding] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const eventsQuery = useMemoFirebase(() => {
    if (!user) return null;
    return query(
      collection(db, 'events'), 
      where('organizerId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );
  }, [db, user]);

  const { data: events, isLoading } = useCollection(eventsQuery);

  const handleSeed = async () => {
    if (!user) return;
    setSeeding(true);
    try {
      await seedSampleEvents(db, user.uid);
      toast({
        title: "Platform Populated!",
        description: "Sample events across all categories have been added.",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Seeding Failed",
        description: error.message,
      });
    } finally {
      setSeeding(false);
    }
  };

  const STATS = [
    { label: "Total Revenue", value: "$12,450.00", icon: DollarSign, trend: "+12.5%", color: "text-green-600 bg-green-50" },
    { label: "Tickets Sold", value: "842", icon: Ticket, trend: "+8.2%", color: "text-blue-600 bg-blue-50" },
    { label: "Total Attendees", value: "1,205", icon: Users, trend: "+14.1%", color: "text-purple-600 bg-purple-50" },
    { label: "Active Events", value: events?.filter(e => e.status === 'published').length || "0", icon: Calendar, trend: "0%", color: "text-orange-600 bg-orange-50" },
  ];

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
        <h1 className="text-2xl font-bold font-headline">Please log in to view your dashboard</h1>
        <Button asChild className="rounded-xl"><Link href="/login">Login</Link></Button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-6 py-12 space-y-10">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl md:text-4xl font-headline font-bold">Organizer Hub</h1>
          <p className="text-muted-foreground">Monitor performance and manage your experiences</p>
        </div>
        <div className="flex gap-3">
          <Button 
            variant="outline" 
            className="rounded-xl font-bold gap-2 border-primary/20 text-primary hover:bg-primary/5"
            onClick={handleSeed}
            disabled={seeding}
          >
            {seeding ? <Loader2 className="w-4 h-4 animate-spin" /> : <Database className="w-4 h-4" />}
            Populate Demo Data
          </Button>
          <Button size="lg" className="rounded-xl font-bold gap-2 shadow-lg shadow-primary/20" asChild>
            <Link href="/organizer/create">
              <Plus className="w-5 h-5" /> Create New Event
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {STATS.map((stat) => (
          <Card key={stat.label} className="border-none shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-2.5 rounded-xl ${stat.color}`}>
                  <stat.icon className="w-5 h-5" />
                </div>
                <Badge variant="secondary" className="bg-green-50 text-green-700 border-none font-bold">
                  <TrendingUp className="w-3 h-3 mr-1" /> {stat.trend}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground font-medium">{stat.label}</p>
              <h3 className="text-3xl font-bold mt-1 font-headline">{stat.value}</h3>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 border-none shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Revenue Analytics</CardTitle>
              <CardDescription>Daily revenue trends for the past 7 days</CardDescription>
            </div>
            <Button variant="outline" size="sm" className="rounded-lg">Download Report</Button>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={REVENUE_DATA}>
                  <defs>
                    <linearGradient id="colorTotal" x1="0" x1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--muted))" />
                  <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}}
                  />
                  <Tooltip 
                    contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                  />
                  <Area type="monotone" dataKey="total" stroke="hsl(var(--primary))" strokeWidth={3} fillOpacity={1} fill="url(#colorTotal)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle>Ticket Sales</CardTitle>
            <CardDescription>Monthly ticket volume</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={ATTENDEE_DATA}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--muted))" />
                  <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}}
                  />
                  <YAxis hide />
                  <Tooltip 
                    cursor={{fill: 'hsl(var(--primary) / 0.05)'}}
                    contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                  />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} barSize={30} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 border-none shadow-sm overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between bg-muted/10">
            <div>
              <CardTitle>Your Events</CardTitle>
              <CardDescription>Manage status and view details</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-primary font-bold">View All</Button>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="flex justify-center p-12">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : (
              <Table>
                <TableHeader className="bg-muted/30">
                  <TableRow>
                    <TableHead className="pl-6">Event</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead className="text-right pr-6"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {events?.map((event) => (
                    <TableRow key={event.id} className="hover:bg-muted/5">
                      <TableCell className="pl-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="relative w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-bold text-xs shrink-0 overflow-hidden">
                            {event.bannerImageUrl ? (
                              <Image src={event.bannerImageUrl} fill className="object-cover" alt="" data-ai-hint="event photo" />
                            ) : event.category?.substring(0, 2).toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <p className="font-bold truncate">{event.title}</p>
                            <p className="text-xs text-muted-foreground">
                              {isMounted && event.startDate?.seconds ? new Date(event.startDate.seconds * 1000).toLocaleDateString() : 'Loading...'}
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={event.status === 'published' ? 'default' : 'secondary'} className="rounded-full px-3 font-medium">
                          {event.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm font-bold text-primary">${event.price}</TableCell>
                      <TableCell className="text-right pr-6">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="rounded-full">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="rounded-xl w-48">
                            <DropdownMenuItem asChild>
                              <Link href={`/organizer/create`} className="gap-2">
                                <Edit2 className="w-4 h-4" /> Edit Event
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem className="gap-2">
                              <BarChart3 className="w-4 h-4" /> Analytics
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                              <Link href={`/events/${event.id}`} className="gap-2">
                                <ExternalLink className="w-4 h-4" /> Public Page
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem className="gap-2 text-destructive">
                              <Trash2 className="w-4 h-4" /> Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                  {(!events || events.length === 0) && (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-16 text-muted-foreground">
                        <div className="flex flex-col items-center gap-2">
                          <Calendar className="w-8 h-8 opacity-20" />
                          <p>No events found. Ready to host your first one?</p>
                          <Button variant="link" asChild><Link href="/organizer/create">Create an Event</Link></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm h-full flex flex-col">
          <CardHeader>
            <CardTitle>Top Insights</CardTitle>
            <CardDescription>Key metrics for quick decision making</CardDescription>
          </CardHeader>
          <CardContent className="space-y-8 flex-1">
            <div className="space-y-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground font-medium">Global Ticket Inventory</span>
                <span className="font-bold">78% Sold</span>
              </div>
              <div className="h-2.5 w-full bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-primary" style={{ width: '78%' }} />
              </div>
            </div>
            
            <div className="space-y-4">
               <h4 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Most Popular This Week</h4>
               <div className="space-y-4">
                 {[
                   { name: 'Global Tech Summit', count: 85, revenue: '2.4k' },
                   { name: 'Music Festival', count: 120, revenue: '1.8k' },
                   { name: 'Baking Class', count: 42, revenue: '0.9k' }
                 ].map((item, idx) => (
                   <div key={idx} className="flex items-center gap-3 group">
                     <div className="w-10 h-10 rounded-xl bg-muted group-hover:bg-primary/10 flex items-center justify-center text-muted-foreground group-hover:text-primary font-bold text-xs transition-colors">
                       {item.name.substring(0, 2)}
                     </div>
                     <div className="flex-1 min-w-0">
                       <p className="text-sm font-bold truncate">{item.name}</p>
                       <p className="text-xs text-muted-foreground">{item.count} tickets sold</p>
                     </div>
                     <span className="text-sm font-bold text-green-600">+${item.revenue}</span>
                   </div>
                 ))}
               </div>
            </div>

            <div className="pt-4 border-t mt-auto">
              <Button className="w-full rounded-xl py-6" variant="outline">
                Generate Full Sales Report
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}