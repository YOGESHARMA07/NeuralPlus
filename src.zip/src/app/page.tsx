"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowRight, 
  Calendar as CalendarIcon, 
  MapPin, 
  Music, 
  Code, 
  Utensils, 
  Palette, 
  Trophy,
  Zap,
  Sparkles,
  Loader2
} from "lucide-react";
import { useUser, useCollection, useFirestore, useMemoFirebase } from "@/firebase";
import { collection, query, where, limit } from "firebase/firestore";
import { personalizedEventRecommendations, type PersonalizedEventRecommendationsOutput } from "@/ai/flows/personalized-event-recommendations";

const CATEGORIES = [
  { name: "Music", icon: Music, color: "bg-blue-100 text-blue-600" },
  { name: "Tech", icon: Code, color: "bg-orange-100 text-orange-600" },
  { name: "Food", icon: Utensils, color: "bg-green-100 text-green-600" },
  { name: "Arts", icon: Palette, color: "bg-purple-100 text-purple-600" },
  { name: "Sports", icon: Trophy, color: "bg-yellow-100 text-yellow-600" },
  { name: "Business", icon: Zap, color: "bg-cyan-100 text-cyan-600" },
];

export default function Home() {
  const { user } = useUser();
  const db = useFirestore();
  const [recommendations, setRecommendations] = useState<PersonalizedEventRecommendationsOutput | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);
  const [isMounted, setIsMounted] = useState(false);
  const hasFetchedRecommendations = useRef(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const heroImage = (PlaceHolderImages || []).find(img => img.id === 'hero-bg');

  // Fetch Featured Events
  const featuredQuery = useMemoFirebase(() => {
    return query(collection(db, 'events'), where('status', '==', 'published'), limit(3));
  }, [db]);
  const { data: featuredEvents } = useCollection(featuredQuery);

  // AI Recommendations logic
  useEffect(() => {
    if (user && featuredEvents && featuredEvents.length > 0 && !hasFetchedRecommendations.current) {
      const getRecommendations = async () => {
        setLoadingAi(true);
        hasFetchedRecommendations.current = true;
        try {
          const result = await personalizedEventRecommendations({
            interests: ['tech', 'music'], 
            browsingHistory: featuredEvents.map(e => e.title)
          });
          setRecommendations(result);
        } catch (error) {
          console.error('AI Error:', error);
        } finally {
          setLoadingAi(false);
        }
      };
      getRecommendations();
    }
  }, [user, featuredEvents]);

  return (
    <div className="flex flex-col gap-20 pb-20">
      {/* Hero Section */}
      <section className="relative w-full h-[650px] flex items-center justify-center overflow-hidden">
        <Image 
          src={heroImage?.imageUrl || "https://picsum.photos/seed/1/1200/600"} 
          alt="Hero"
          fill
          className="object-cover brightness-[0.35] scale-105"
          priority
          data-ai-hint="concert crowd"
        />
        <div className="relative z-10 max-w-5xl mx-auto text-center px-6 space-y-8">
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-1000">
            <Badge className="bg-primary/20 text-primary border-primary/20 px-5 py-2 text-sm mb-6 rounded-full font-bold backdrop-blur-md">
              Over 5,000+ Experiences Waiting For You
            </Badge>
            <h1 className="text-5xl md:text-8xl font-headline font-bold text-white tracking-tight leading-[1.1]">
              Live Life to the <span className="text-primary italic underline underline-offset-8">Fullest</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto mt-6 leading-relaxed font-medium">
              EventFlex is your gateway to world-class conferences, intimate workshops, and epic festivals. 
            </p>
            <div className="flex flex-col sm:flex-row gap-5 justify-center pt-10">
              <Button size="lg" className="h-16 px-10 text-lg font-bold rounded-2xl shadow-2xl shadow-primary/20" asChild>
                <Link href="/events">Explore Now</Link>
              </Button>
              <Button size="lg" variant="outline" className="h-16 px-10 text-lg font-bold bg-white/5 text-white border-white/20 hover:bg-white/10 backdrop-blur-md rounded-2xl" asChild>
                <Link href="/organizer">Host an Event</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-6 w-full">
        <div className="flex flex-col md:flex-row items-end justify-between mb-12 gap-4">
          <div className="space-y-2 text-center md:text-left">
            <h2 className="text-4xl font-headline font-bold">Find Your Vibe</h2>
            <p className="text-muted-foreground text-lg">Browse curated events across popular interests</p>
          </div>
          <Button variant="ghost" className="text-primary gap-2 font-bold text-lg" asChild>
            <Link href="/events">View All <ArrowRight className="w-5 h-5" /></Link>
          </Button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {CATEGORIES.map((cat) => (
            <Link key={cat.name} href={`/events?category=${cat.name}`}>
              <Card className="hover:border-primary transition-all cursor-pointer group h-full border-none bg-muted/30 shadow-none hover:bg-white hover:shadow-xl hover:shadow-primary/5">
                <CardContent className="p-8 flex flex-col items-center justify-center text-center gap-4">
                  <div className={`p-5 rounded-[2rem] ${cat.color} group-hover:scale-110 group-hover:rotate-3 transition-transform duration-500`}>
                    <cat.icon className="w-10 h-10" />
                  </div>
                  <span className="font-bold text-xl">{cat.name}</span>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* AI Recommendations Section */}
      {user && (
        <section className="max-w-7xl mx-auto px-6 w-full">
          <div className="bg-primary/5 rounded-[2.5rem] p-10 md:p-16 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-10">
              <Sparkles className="w-32 h-32 text-primary" />
            </div>
            
            <div className="flex items-center gap-3 mb-8">
              <div className="bg-primary/10 p-2 rounded-lg">
                <Sparkles className="w-6 h-6 text-primary" />
              </div>
              <h2 className="text-3xl font-headline font-bold">Personalized For You</h2>
            </div>

            {loadingAi ? (
              <div className="flex flex-col items-center justify-center py-12 gap-4">
                <Loader2 className="w-10 h-10 animate-spin text-primary" />
                <p className="text-muted-foreground font-medium animate-pulse">Analyzing your interests...</p>
              </div>
            ) : recommendations ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {recommendations.recommendedEvents.map((rec) => (
                  <Card key={rec.id} className="border-none bg-white/80 backdrop-blur-sm rounded-2xl hover:shadow-lg transition-all group">
                    <CardContent className="p-6 space-y-4">
                      <h3 className="font-bold text-xl group-hover:text-primary transition-colors">{rec.title}</h3>
                      <p className="text-sm text-muted-foreground line-clamp-2">{rec.description}</p>
                      <Button variant="link" className="p-0 h-auto font-bold gap-2 text-primary group-hover:underline" asChild>
                        <Link href={`/events/${rec.id}`}>View Details <ArrowRight className="w-4 h-4" /></Link>
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-10 opacity-50">
                <p>Explore more events to get AI-powered recommendations!</p>
              </div>
            )}
          </div>
        </section>
      )}

      {/* Featured Events */}
      <section className="max-w-7xl mx-auto px-6 w-full">
        <div className="flex items-end justify-between mb-12">
          <div className="space-y-2">
            <h2 className="text-4xl font-headline font-bold">Top Picks</h2>
            <p className="text-muted-foreground text-lg">Unforgettable experiences selected just for you</p>
          </div>
          <Button variant="ghost" className="hidden sm:flex text-primary gap-2 font-bold text-lg" asChild>
            <Link href="/events">Browse Map <MapPin className="w-5 h-5" /></Link>
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {featuredEvents ? featuredEvents.map((event) => (
            <Link key={event.id} href={`/events/${event.id}`}>
              <Card className="overflow-hidden hover:shadow-2xl transition-all duration-500 group border-none bg-white rounded-[2rem] h-full flex flex-col">
                <div className="relative h-64 overflow-hidden">
                  <Image 
                    src={event.bannerImageUrl || `https://picsum.photos/seed/${event.id}/600/400`} 
                    alt={event.title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-700"
                    data-ai-hint="event banner"
                  />
                  <div className="absolute top-5 right-5">
                    <Badge className="bg-white/90 text-primary hover:bg-white font-bold backdrop-blur-md px-4 py-1.5 rounded-full border-none shadow-lg">
                      {event.price === 0 ? 'FREE' : `$${event.price}`}
                    </Badge>
                  </div>
                  <div className="absolute bottom-5 left-5">
                    <Badge variant="secondary" className="bg-black/40 text-white border-none backdrop-blur-md px-4 py-1 rounded-full uppercase tracking-widest text-[10px]">
                      {event.category}
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-8 flex-1 flex flex-col">
                  <h3 className="text-2xl font-bold mb-4 group-hover:text-primary transition-colors line-clamp-1 leading-tight">
                    {event.title}
                  </h3>
                  <div className="space-y-3 mb-8">
                    <div className="flex items-center gap-3 text-muted-foreground font-medium">
                      <div className="bg-primary/10 p-1.5 rounded-lg text-primary">
                        <CalendarIcon className="w-4 h-4" />
                      </div>
                      <span className="text-sm">
                        {isMounted && event.startDate?.seconds ? new Date(event.startDate.seconds * 1000).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'TBA'}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-muted-foreground font-medium">
                      <div className="bg-primary/10 p-1.5 rounded-lg text-primary">
                        <MapPin className="w-4 h-4" />
                      </div>
                      <span className="text-sm truncate">{event.location || (event.isVirtual ? 'Virtual' : 'Global')}</span>
                    </div>
                  </div>
                  <div className="mt-auto pt-6 border-t flex items-center justify-between">
                    <span className="text-primary font-bold hover:underline flex items-center gap-1">
                      Learn More <ArrowRight className="w-4 h-4" />
                    </span>
                    <Button size="sm" className="rounded-full px-6 font-bold">
                      Book Seat
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </Link>
          )) : (
            [1,2,3].map(i => <div key={i} className="h-[400px] bg-muted animate-pulse rounded-[2rem]" />)
          )}
        </div>
      </section>

      {/* Organizer Call to Action */}
      <section className="max-w-7xl mx-auto px-6 w-full">
        <div className="bg-foreground rounded-[3rem] p-10 md:p-24 flex flex-col md:flex-row items-center gap-16 overflow-hidden relative group">
          <div className="absolute -top-20 -right-20 w-96 h-96 bg-primary/20 rounded-full blur-[100px] group-hover:bg-primary/30 transition-colors duration-1000" />
          <div className="absolute -bottom-20 -left-20 w-96 h-96 bg-accent/20 rounded-full blur-[100px]" />
          
          <div className="relative z-10 flex-1 space-y-8 text-center md:text-left">
            <h2 className="text-4xl md:text-6xl font-headline font-bold leading-tight text-white">
              Your Vision, Our <span className="text-primary">Platform.</span>
            </h2>
            <p className="text-xl text-gray-400 max-w-xl leading-relaxed">
              Join thousands of organizers who trust EventFlex to power their music festivals, tech summits, and creative workshops.
            </p>
            <div className="flex flex-wrap gap-5 justify-center md:justify-start">
              <Button size="lg" className="h-16 px-10 font-bold rounded-2xl text-lg shadow-xl shadow-primary/20" asChild>
                <Link href="/organizer">Start Hosting</Link>
              </Button>
              <Button size="lg" variant="outline" className="h-16 px-10 font-bold rounded-2xl text-lg border-white/20 text-white hover:bg-white/10" asChild>
                <Link href="/organizer/pricing">Pricing Plans</Link>
              </Button>
            </div>
          </div>
          
          <div className="flex-1 w-full max-w-md relative animate-in zoom-in duration-1000">
            <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 border border-white/10 shadow-2xl space-y-6">
               <div className="flex items-center justify-between border-b border-white/10 pb-6">
                 <span className="font-bold text-white text-lg">Global Sales Pulse</span>
                 <Badge className="bg-green-500 text-white border-none font-bold">+24%</Badge>
               </div>
               <div className="space-y-5">
                 {[
                   { name: 'Alex Johnson', time: '2m ago', type: 'VIP Ticket' },
                   { name: 'Sarah Chen', time: '12m ago', type: 'Standard' },
                   { name: 'Mike Ross', time: '1h ago', type: 'Early Bird' }
                 ].map((sale, i) => (
                   <div key={i} className="flex items-center gap-4">
                     <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm">
                       {sale.name.split(' ').map(n => n[0]).join('')}
                     </div>
                     <div className="flex-1">
                       <p className="text-sm font-bold text-white">New Sale: {sale.type}</p>
                       <p className="text-xs text-gray-400">{sale.name} • {sale.time}</p>
                     </div>
                     <Zap className="w-4 h-4 text-primary animate-pulse" />
                   </div>
                 ))}
               </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
