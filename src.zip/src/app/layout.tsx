import type {Metadata} from 'next';
import './globals.css';
import { Navbar } from '@/components/navbar';
import { Toaster } from '@/components/ui/toaster';
import { FirebaseClientProvider } from '@/firebase';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'EventFlex Hub | Discover & Manage Events',
  description: 'The ultimate marketplace for organizers and attendees to connect over incredible experiences.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300..700&family=Inter:wght@100..900&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased min-h-screen flex flex-col">
        <FirebaseClientProvider>
          <Navbar />
          <main className="flex-grow">
            {children}
          </main>
          <footer className="bg-card border-t py-12 px-6">
            <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="space-y-4">
                <h3 className="font-headline text-2xl font-bold text-primary">EventFlex</h3>
                <p className="text-muted-foreground text-sm">Connecting the world through shared experiences and unforgettable events.</p>
              </div>
              <div>
                <h4 className="font-bold mb-4">Explore</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li><Link href="/events" className="hover:text-primary">All Events</Link></li>
                  <li><Link href="/events?category=Music" className="hover:text-primary">Concerts</Link></li>
                  <li><Link href="/events?category=Tech" className="hover:text-primary">Tech Conferences</Link></li>
                  <li><Link href="/events?category=Arts" className="hover:text-primary">Arts & Culture</Link></li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold mb-4">Support</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li><Link href="#" className="hover:text-primary">Help Center</Link></li>
                  <li><Link href="#" className="hover:text-primary">Contact Us</Link></li>
                  <li><Link href="#" className="hover:text-primary">Terms of Service</Link></li>
                  <li><Link href="#" className="hover:text-primary">Privacy Policy</Link></li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold mb-4">Organizers</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li><Link href="/organizer/create" className="hover:text-primary">Host an Event</Link></li>
                  <li><Link href="/organizer" className="hover:text-primary">Organizer Dashboard</Link></li>
                  <li><Link href="/organizer/check-in" className="hover:text-primary">Attendee Check-in</Link></li>
                </ul>
              </div>
            </div>
            <div className="max-w-7xl mx-auto mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
              © 2024 EventFlex Hub. All rights reserved.
            </div>
          </footer>
          <Toaster />
        </FirebaseClientProvider>
      </body>
    </html>
  );
}