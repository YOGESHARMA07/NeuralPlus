import { 
  collection, 
  doc, 
  runTransaction, 
  serverTimestamp,
  query,
  where,
  getDocs,
  collectionGroup,
  increment,
  type Firestore,
  type Timestamp
} from 'firebase/firestore';
import { setDocumentNonBlocking, updateDocumentNonBlocking } from '@/firebase/non-blocking-updates';

// --- Core Entities ---

export interface UserProfile {
  id: string;
  email: string;
  displayName: string;
  profilePictureUrl?: string;
  role: 'attendee' | 'organizer' | 'admin';
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface Venue {
  id: string;
  name: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  latitude?: number;
  longitude?: number;
}

export interface Event {
  id: string;
  organizerId: string;
  venueId?: string;
  title: string;
  description: string;
  category: string;
  tagIds: string[];
  bannerImageUrl?: string;
  thumbnailUrl?: string;
  startDate: Timestamp;
  endDate: Timestamp;
  status: 'draft' | 'published' | 'cancelled' | 'completed' | 'archived';
  isVirtual: boolean;
  virtualEventLink?: string;
  price: number;
  createdAt: Timestamp;
  updatedAt: Timestamp;
  location?: string;
}

export interface TicketType {
  id: string;
  eventId: string;
  organizerId: string;
  name: string;
  description: string;
  price: number;
  quantityAvailable: number;
  quantitySold: number;
  maxPerOrder: number;
  salesStartTime: Timestamp;
  salesEndTime: Timestamp;
}

export interface Booking {
  id: string;
  attendeeId: string;
  eventId: string;
  organizerId: string;
  bookingDate: Timestamp;
  totalAmount: number;
  status: 'pending' | 'confirmed' | 'cancelled' | 'refunded';
  paymentTransactionId: string;
  qrCodeUrl: string;
  invoiceUrl: string;
}

export interface Ticket {
  id: string;
  bookingId: string;
  ticketTypeId: string;
  ticketCode: string;
  priceAtBooking: number;
  status: 'valid' | 'checked-in' | 'invalid' | 'transferred';
  attendeeName: string;
  attendeeEmail: string;
  organizerId: string;
  eventId: string;
  attendeeId: string;
  checkedInAt?: Timestamp;
}

// --- Data Operations ---

/**
 * Atomic booking function using Firestore Transaction.
 */
export async function bookTickets(
  db: Firestore, 
  attendeeId: string, 
  attendeeName: string,
  attendeeEmail: string,
  eventId: string, 
  ticketTypeId: string, 
  quantity: number
) {
  return await runTransaction(db, async (transaction) => {
    const eventRef = doc(db, 'events', eventId);
    const ticketTypeRef = doc(db, 'events', eventId, 'ticketTypes', ticketTypeId);
    
    const eventSnap = await transaction.get(eventRef);
    const ticketTypeSnap = await transaction.get(ticketTypeRef);
    
    if (!eventSnap.exists()) throw new Error("Event not found");
    if (!ticketTypeSnap.exists()) throw new Error("Ticket type not found");
    
    const ticketData = ticketTypeSnap.data() as TicketType;
    
    if (ticketData.quantityAvailable < quantity) {
      throw new Error("Insufficient tickets available");
    }

    const bookingId = doc(collection(db, 'users', attendeeId, 'bookings')).id;
    const bookingRef = doc(db, 'users', attendeeId, 'bookings', bookingId);
    
    const totalAmount = ticketData.price * quantity;

    // 1. Create Booking
    transaction.set(bookingRef, {
      id: bookingId,
      attendeeId,
      eventId,
      organizerId: eventSnap.data()?.organizerId,
      totalAmount,
      status: 'confirmed',
      bookingDate: serverTimestamp(),
      paymentTransactionId: `TXN-${Date.now()}`,
      qrCodeUrl: `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${bookingId}`,
      invoiceUrl: '#'
    });

    // 2. Decrement Ticket Inventory
    transaction.update(ticketTypeRef, {
      quantityAvailable: increment(-quantity),
      quantitySold: increment(quantity)
    });

    // 3. Create Ticket Instances (using bookingTickets as expected by rules)
    for (let i = 0; i < quantity; i++) {
      const ticketId = doc(collection(bookingRef, 'bookingTickets')).id;
      const ticketRef = doc(bookingRef, 'bookingTickets', ticketId);
      transaction.set(ticketRef, {
        id: ticketId,
        bookingId,
        ticketTypeId,
        ticketCode: Math.random().toString(36).substring(7).toUpperCase(),
        priceAtBooking: ticketData.price,
        status: 'valid',
        attendeeName, 
        attendeeEmail,
        organizerId: eventSnap.data()?.organizerId,
        eventId,
        attendeeId
      });
    }

    return { bookingId };
  });
}

/**
 * Validates and marks a ticket as checked in.
 */
export async function checkInTicket(db: Firestore, ticketCode: string, organizerId: string) {
  const ticketsQuery = query(
    collectionGroup(db, 'bookingTickets'), 
    where('ticketCode', '==', ticketCode.toUpperCase()),
    where('organizerId', '==', organizerId)
  );
  
  const querySnap = await getDocs(ticketsQuery);
  
  if (querySnap.empty) {
    throw new Error("Invalid ticket code or permission denied.");
  }
  
  const ticketDoc = querySnap.docs[0];
  const ticketData = ticketDoc.data() as Ticket;
  
  if (ticketData.status === 'checked-in') {
    throw new Error("Ticket has already been used.");
  }
  
  updateDocumentNonBlocking(ticketDoc.ref, {
    status: 'checked-in',
    checkedInAt: serverTimestamp()
  });
  
  return { success: true, attendeeName: ticketData.attendeeName };
}

/**
 * Seed 110+ Sample Events into Firestore across all categories.
 */
export async function seedSampleEvents(db: Firestore, organizerId: string) {
  const CATEGORIES = ["Music", "Tech", "Food", "Arts", "Business", "Sports"];
  const TITLES = [
    "Summit", "Festival", "Workshop", "Conference", "Expo", "Meetup", "Gala", "Concert", "Masterclass", "Showcase"
  ];
  const MODIFIERS = [
    "Global", "Local", "International", "Annual", "Summer", "Winter", "Spring", "Fall", "Ultimate", "Elite"
  ];
  const CITIES = ["New York, NY", "San Francisco, CA", "London, UK", "Tokyo, JP", "Berlin, DE", "Austin, TX", "Paris, FR"];

  // Generate 110 events (approx 18 per category) to fulfill "100 plus" requirement
  for (let i = 0; i < 110; i++) {
    const category = CATEGORIES[i % CATEGORIES.length];
    const modifier = MODIFIERS[Math.floor(Math.random() * MODIFIERS.length)];
    const title = TITLES[Math.floor(Math.random() * TITLES.length)];
    const city = CITIES[Math.floor(Math.random() * CITIES.length)];
    const fullTitle = `${modifier} ${category} ${title} #${i + 1}`;
    
    const eventId = doc(collection(db, 'events')).id;
    const eventRef = doc(db, 'events', eventId);
    
    const startDate = new Date();
    startDate.setDate(startDate.getDate() + Math.floor(Math.random() * 180)); // Random date in next 6 months
    startDate.setHours(9 + Math.floor(Math.random() * 10), 0, 0, 0); // Random business hour
    
    const eventData = {
      id: eventId,
      organizerId,
      title: fullTitle,
      description: `Join us for the ${fullTitle}! This is a premier ${category} experience held in ${city}. Whether you are an industry professional or a curious enthusiast, this ${title.toLowerCase()} offers unparalleled opportunities for networking, learning, and growth. Expect world-class speakers, hands-on activities, and a community of like-minded individuals.`,
      category: category,
      tagIds: [category.toLowerCase(), modifier.toLowerCase(), "live", "featured"],
      startDate: startDate,
      endDate: new Date(startDate.getTime() + 10800000), // 3 hours duration
      status: 'published',
      price: Math.floor(Math.random() * 250),
      isVirtual: Math.random() > 0.8,
      location: Math.random() > 0.8 ? "Virtual Event" : `${city}, Venue ${Math.floor(Math.random() * 10) + 1}`,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      bannerImageUrl: `https://picsum.photos/seed/${eventId}/1200/600`
    };

    setDocumentNonBlocking(eventRef, eventData, { merge: true });

    // Seed a corresponding ticket type for booking
    const ttId = doc(collection(eventRef, 'ticketTypes')).id;
    setDocumentNonBlocking(doc(eventRef, 'ticketTypes', ttId), {
      id: ttId,
      eventId,
      organizerId,
      name: "Standard Access",
      description: "Full event access.",
      price: eventData.price,
      quantityAvailable: 1000,
      quantitySold: 0,
      maxPerOrder: 5,
      salesStartTime: serverTimestamp(),
      salesEndTime: startDate
    }, { merge: true });
  }
}
