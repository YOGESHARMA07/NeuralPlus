import data from '@/app/lib/placeholder-images.json';

export type ImagePlaceholder = {
  id: string;
  description: string;
  imageUrl: string;
  imageHint: string;
};

// Robust check for JSON data structure
export const PlaceHolderImages: ImagePlaceholder[] = Array.isArray((data as any)?.placeholderImages) 
  ? (data as any).placeholderImages 
  : [];
