'use client';

import { useState, useRef, useEffect } from 'react';
import { useFirestore, useUser, useCollection, useMemoFirebase, addDocumentNonBlocking } from '@/firebase';
import { collection, serverTimestamp, query, orderBy, limit } from 'firebase/firestore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Send, Loader2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface EventChatProps {
  eventId: string;
}

export function EventChat({ eventId }: EventChatProps) {
  const { user } = useUser();
  const db = useFirestore();
  const [message, setMessage] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  const messagesQuery = useMemoFirebase(() => {
    return query(
      collection(db, 'events', eventId, 'messages'),
      orderBy('createdAt', 'asc'),
      limit(50)
    );
  }, [db, eventId]);

  const { data: messages, isLoading } = useCollection(messagesQuery);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !message.trim()) return;

    // Standard non-blocking write pattern
    addDocumentNonBlocking(collection(db, 'events', eventId, 'messages'), {
      text: message.trim(),
      userId: user.uid,
      userName: user.displayName || 'Anonymous',
      userAvatar: user.photoURL,
      createdAt: serverTimestamp(),
    });
    
    setMessage('');
  };

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center space-y-4 border rounded-2xl bg-muted/10">
        <p className="text-muted-foreground">Join the conversation with other attendees!</p>
        <Button variant="outline" asChild>
          <a href="/login">Log in to Chat</a>
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[500px] border rounded-2xl overflow-hidden bg-card">
      <div className="p-4 border-b bg-muted/30">
        <h3 className="font-bold">Community Chat</h3>
        <p className="text-xs text-muted-foreground">Connect with other attendees in real-time</p>
      </div>

      <ScrollArea ref={scrollRef} className="flex-1 p-4">
        {isLoading ? (
          <div className="flex justify-center py-10">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
          </div>
        ) : messages && messages.length > 0 ? (
          <div className="space-y-4">
            {messages.map((msg) => (
              <div key={msg.id} className={`flex gap-3 ${msg.userId === user.uid ? 'flex-row-reverse' : ''}`}>
                <Avatar className="w-8 h-8 shrink-0">
                  <AvatarImage src={msg.userAvatar} />
                  <AvatarFallback>{msg.userName.substring(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className={`flex flex-col ${msg.userId === user.uid ? 'items-end' : ''}`}>
                  <div className="flex items-baseline gap-2 mb-1">
                    <span className="text-xs font-bold">{msg.userName}</span>
                    <span className="text-[10px] text-muted-foreground">
                      {msg.createdAt?.seconds ? formatDistanceToNow(new Date(msg.createdAt.seconds * 1000), { addSuffix: true }) : 'Just now'}
                    </span>
                  </div>
                  <div className={`px-3 py-2 rounded-2xl text-sm ${msg.userId === user.uid ? 'bg-primary text-primary-foreground rounded-tr-none' : 'bg-muted rounded-tl-none'}`}>
                    {msg.text}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground opacity-50 py-20">
            <p>No messages yet. Be the first to say hi!</p>
          </div>
        )}
      </ScrollArea>

      <form onSubmit={handleSendMessage} className="p-4 border-t flex gap-2">
        <Input
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type a message..."
          className="rounded-full bg-muted/50 border-none"
        />
        <Button size="icon" type="submit" className="rounded-full shrink-0" disabled={!message.trim()}>
          <Send className="w-4 h-4" />
        </Button>
      </form>
    </div>
  );
}
