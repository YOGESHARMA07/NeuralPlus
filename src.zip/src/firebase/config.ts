export const firebaseConfig = {
  "projectId": "studio-6782884943-17217",
  "appId": "1:737913529966:web:9d03a403d9969d0c7b687f",
  "apiKey": "AIzaSyD92fKTrGu6T3gnSgOODiX9fYffglS1Ei8",
  "authDomain": "studio-6782884943-17217.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "737913529966"
};
